<?php
// Load the XML source
$xml = new DOMDocument;
$xml->load('sport.xml');
$xsl = new DOMDocument;
$xsl->substituteEntities = true; 
//$xsl->load('images.xsl');

// Configure the transformer
//$proc = new XSLTProcessor;
//$proc->importStyleSheet($xsl); // attach the xsl rules

//echo $proc->transformToXML($xml);

echo'
                  <h1>Sport</h1>
                  <div class="margin">
                     <div class="s-12 m-6 l-4">
                            <xsl:for-each select="/sport/image1">
                       <img src="{path}" />
                        <xsl:value-of select="Category"/><br></br>
                       <xsl:value-of select="name"/><br></br>
                        <xsl:value-of select="description"/><br></br>
                          </xsl:for-each>
                       
                        <form class="customform s-12 margin-bottom2x" action="">
                           <div><button class="button rounded-btn submit-btn s-12" type="submit">Rate</button></div>
                        </form>
                     
                     </div>
                     <div class="s-12 m-6 l-4">
                        <xsl:for-each select="/sport/image2">
                       <img src="{path}" />
                        <xsl:value-of select="Category"/><br></br>
                       <xsl:value-of select="name"/><br></br>
                        <xsl:value-of select="description"/><br></br>
                          </xsl:for-each>
                        <form class="customform s-12 margin-bottom2x" action="">
                           <div><button class="button rounded-btn submit-btn s-12" type="submit">Rate</button></div>
                        </form>
                     </div>
                     <div class="s-12 m-6 l-4">
                        <xsl:for-each select="/sport/image3">
                       <img src="{path}" />
                        <xsl:value-of select="Category"/><br></br>
                       <xsl:value-of select="name"/><br></br>
                        <xsl:value-of select="description"/><br></br>
                          </xsl:for-each>
                        <form class="customform s-12 margin-bottom2x" action="">
                           <div><button class="button rounded-btn submit-btn s-12" type="submit">Rate</button></div>
                        </form>
                     </div>
                     <div class="s-12 m-6 l-4">
                        <xsl:for-each select="/sport/image4">
                       <img src="{path}" />
                        <xsl:value-of select="Category"/><br></br>
                       <xsl:value-of select="name"/><br></br>
                        <xsl:value-of select="description"/><br></br>
                          </xsl:for-each>
                        <form class="customform s-12 margin-bottom2x" action="">
                           <div><button class="button rounded-btn submit-btn s-12" type="submit">Rate</button></div>
                        </form>
                     </div>
                     <div class="s-12 m-6 l-4">
                            <xsl:for-each select="/sport/image5">
                       <img src="{path}" />
                        <xsl:value-of select="Category"/><br></br>
                       <xsl:value-of select="name"/><br></br>
                        <xsl:value-of select="description"/><br></br>
                          </xsl:for-each>
                        <form class="customform s-12 margin-bottom2x" action="">
                           <div><button class="button rounded-btn submit-btn s-12" type="submit">Rate</button></div>
                        </form>
                     </div>
                     <div class="s-12 m-6 l-4">
                        <xsl:for-each select="/sport/image6">
                       <img src="{path}" />
                        <xsl:value-of select="Category"/><br></br>
                       <xsl:value-of select="name"/><br></br>
                        <xsl:value-of select="description"/><br></br>
                          </xsl:for-each>
                        <form class="customform s-12 margin-bottom2x" action="">
                           <div><button class="button rounded-btn submit-btn s-12" type="submit">Rate</button></div>
                        </form>
                     </div>
                     <div class="s-12 m-6 l-4">
                        <xsl:for-each select="/sport/image7">
                       <img src="{path}" />
                        <xsl:value-of select="Category"/><br></br>
                       <xsl:value-of select="name"/><br></br>
                        <xsl:value-of select="description"/><br></br>
                          </xsl:for-each>
                        <form class="customform s-12 margin-bottom2x" action="">
                           <div><button class="button rounded-btn submit-btn s-12" type="submit">Rate</button></div>
                        </form>
                     </div>
                     <div class="s-12 m-6 l-4">
                          <xsl:for-each select="/sport/image8">
                       <img src="{path}" />
                        <xsl:value-of select="Category"/><br></br>
                       <xsl:value-of select="name"/><br></br>
                        <xsl:value-of select="description"/><br></br>
                          </xsl:for-each>
                        <form class="customform s-12 margin-bottom2x" action="">
                           <div><button class="button rounded-btn submit-btn s-12" type="submit">Rate</button></div>
                        </form>
                     </div>
                     <div class="s-12 m-6 l-4">
                        <xsl:for-each select="/sport/image9">
                       <img src="{path}" />
                        <xsl:value-of select="Category"/><br></br>
                       <xsl:value-of select="name"/><br></br>
                        <xsl:value-of select="description"/><br></br>
                          </xsl:for-each>
                        <form class="customform s-12 margin-bottom2x" action="">
                           <div><button class="button rounded-btn submit-btn s-12" type="submit">Rate</button></div>
                        </form>
                     </div>
                  </div>
' ?>