<?xml version="1.0" encoding="UTF-8" 
<xsl:transform xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
<xsl:output method="html" doctype-public="XSLT-compat" omit-xml-declaration="yes" encoding="UTF-8" indent="yes"/>
<xsl:template match="/">
<html lang="en-US">
   <head>

      <meta charset="UTF-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Funny Pics</title>
      <link rel="stylesheet" href="css/components.css"/>
      <link rel="stylesheet" href="css/icons.css"/>
      <link rel="stylesheet" href="css/responsee.css"/>
    <!--  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'/>-->
      <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>    
   </head>
   <body class="size-1280"  onload="myFunction()">
      <!-- HEADER -->
      <header>
         <div class="line">
            <div class="box">
               <div class="s-6 l-2">
                  <img src="img/logo.png"/>
               </div>
                 
                  <select name="Category">
                          <option value="ANIMALS">Animals</option>
                          <option value="FUNNY">funny</option>
                          <option value="MEDICAL">Medical</option>
                          <option value="MEMES">Memes</option>
                          <option value="RELIGON">Religon</option>
                          <option value="SPORT">Sport</option>
                        </select>
                              <!--  <textarea maxlength="200">
                                Enter Image description here
                                </textarea>-->
                      <form action="Update.php" method="post" enctype="multipart/form-data"/>
                      <input type="file" name="fileToUpload" id="fileToUpload"/>
                     <input type="submit" value="Upload Image" name="submit"/>
               <div class="s-12 l-8 right">
                  <div class="margin">
                     <!--  <form  class="customform s-12 l-8" method="get" action="#animals.xml">
                        <div class="s-9"><input type="text" placeholder="Search form" title="Search form" /></div>
                        <div class="s-3"><button type="submit">Search</button></div>
                     </form>-->
                    <div class="s-12 l-4">
                        <p class="right">3 items / EUR 199</p>
                     </div>
                   
               
                   
                  </div>
               </div>
            </div>
         </div>
         <!-- TOP NAV -->  
          <div class="line">
            <nav>
               <p class="nav-text">Main navigation</p>
               <div class="top-nav s-12 l-10">
                  <ul>
                     <li><a>Animals</a></li>
                     <li><a>Funny</a></li>
                     <li><a>Medical</a></li>
                     <li><a>Memes</a></li>
                     <li><a>Religon</a></li>
                   
                  </ul>
               </div>
               <div class="hide-s hide-m l-2">
                  <i class="icon-facebook_circle icon2x right padding"></i>
               </div>
            </nav>
         </div>
      </header>
      <!-- ASIDE NAV AND CONTENT -->
      <div class="line">
         <div class="box">
            <div class="margin2x">
               <!-- CONTENT -->
  
  
    <section class="s-12 m-8 l-9 right">
                 <div id ="Main">    
<script   src="https://code.jquery.com/jquery-2.2.4.min.js"   integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="   crossorigin="anonymous"></script>

 <?php include('animals.php'); ?>


</div>
</section>

               <!-- ASIDE NAV -->
               <aside class="s-12 m-4 l-3">
                  <div class="aside-nav minimize-on-small">
                     <p class="aside-nav-text">Sidebar navigation</p>
                    <script   src="https://code.jquery.com/jquery-2.2.4.min.js"   integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="   crossorigin="anonymous"></script>
                     <ul>
                        <li><button class='aniBtn'><a>Animals</a></button></li>
                        <script>
                         $(".aniBtn").click(function() {
                          $.ajax({
                            url: "animals.php",
                            success: function(result) {
                              $("#Main").html(result);
                            }
                          });
                        });
                      </script>
                        
                        <li><button class='funBtn'><a>Funny</a></button></li>
                       <script>
                         $(".funBtn").click(function() {
                          $.ajax({
                            url: "funny.php",
                            success: function(result) {
                              $("#Main").html(result);
                            }
                          });
                        });
                      </script>
                       
                        <li><button class='medBtn'> <a>Medical</a></button></li>
                        <script>
                         $(".medBtn").click(function() {
                          $.ajax({
                            url: "medical.php",
                            success: function(result) {
                              $("#Main").html(result);
                            }
                          });
                        });
                      </script>
                        <li><button class='memeBtn'><a>Memes</a></button></li>
                        <script>
                         $(".memeBtn").click(function() {
                          $.ajax({
                            url: "meme.php",
                            success: function(result) {
                              $("#Main").html(result);
                            }
                          });
                        });
                      </script>
                        <li><button class='relBtn'><a>Religon</a></button></li>
                        <script>
                         $(".relBtn").click(function() {
                          $.ajax({
                            url: "religon.php",
                            success: function(result) {
                              $("#Main").html(result);
                            }
                          });
                        });
                      </script>
                        <li><button class='sportBtn'><a>Sport</a></button></li>
                        <script>
                         $(".sportBtn").click(function() {
                          $.ajax({
                            url: "sport.php",
                            success: function(result) {
                              $("#Main").html(result);
                            }
                          });
                        });
                      </script>
                        
                     </ul>
                  </div>
               </aside>
            </div>
         </div>
      </div>
      <!-- FOOTER -->
      <footer class="line">
         <div class="s-12 l-6">
            <p>Copyright 2016, Vision Design - graphic zoo</p>
         </div>
         <div class="s-12 l-6">
            <a class="right" href="http://www.myresponsee.com" title="Responsee - lightweight responsive framework">Design and coding by Responsee Team</a>
         </div>
      </footer>
      <script type="text/javascript" src="js/responsee.js"></script>      
   </body>
</html>
</xsl:template>
</xsl:transform>

?>